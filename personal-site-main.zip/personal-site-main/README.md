my personal site i built using basic html and css will keep updating as my knowledge grows
